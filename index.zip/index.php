<?php 
header('Location: /frontend/web/');
?>